<header id="header">
    <div class="container">
       <div class="header-row">
          <div class="header-column justify-content-start">
             <!-- Logo
                ============================================= -->
             <div class="logo"> <a href="/" title="ORO Airways"><img src="{{asset('airways/images/logo.png')}}" alt="Quickai" width="127" height="29" /></a> </div>
             <!-- Logo end -->
          </div>
          <div class="header-column justify-content-end">
             <!-- Primary Navigation
                ============================================= -->
             <nav class="primary-menu navbar navbar-expand-lg nav-primary-dropdown">
                <div id="header-nav" class="collapse navbar-collapse">
                   <ul class="navbar-nav">
                      <li class="">
                         <a class="dropdown-toggle" href="/">Home</a>

                      </li>
                      <li class="">
                         <a class="dropdown-toggle" href="#">Support</a>

                      </li>
                      <li class="">
                            <a class="dropdown-toggle" href="#"><i class="fas fa-shopping-cart" style="margin-right:5px;"></i> Deals</a>

                         </li>
                      <li class="dropdown" >
                         <a class="dropdown-toggle" href="#">Check Status</a>
                        <ul class="dropdown-menu" style="width:100%;">
                            <div>

                                <input type="text" class="form-control" placeholder="Enter Booking Number Reference:"><br>
                                <input type="text" class="form-control" placeholder="Enter Email:">
                            </div>
                        </ul>
                      </li>

                      <li class="login-signup ml-lg-2"><a class="pl-lg-4 pr-0" data-toggle="modal" data-target="#login-signup" href="#" title="Login / Sign up">Login / Sign up <span class="d-none d-lg-inline-block"><i class="fas fa-user"></i></span></a></li>
                   </ul>
                </div>
             </nav>
             <!-- Primary Navigation end -->
          </div>
          <!-- Collapse Button
             ============================================= -->
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#header-nav"> <span></span> <span></span> <span></span> </button>
       </div>
    </div>
 </header>

