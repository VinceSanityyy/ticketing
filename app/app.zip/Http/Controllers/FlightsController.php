<?php

namespace App\Http\Controllers;

use App\Flights;
use Illuminate\Http\Request;
use App\TempFlight;
use App\TempPayment;
use View;
class FlightsController extends Controller
{
    public function searchFlights(Request $request){
        $flights =  Flights::where('flight_country_from', 'like', '%' . $request->flightFrom . '%')
            ->where('flight_country_from', 'like', '%' . $request->flightFrom . '%')
            ->where('flight_country_to', 'like', '%' . $request->flightTo . '%')
            ->whereDate('flight_schedule', 'like', '%' . $request->flightDepart . '%')
            ->paginate(5);

            return view('airways.flightresult', compact('flights'));
            // return View::make('airways.flightresult')->with('flights', $flights);
    }

    public function confirmDetails ($flight_id){

        $flight = Flights::find($flight_id);
        return view('airways.confirmdetails', compact('flight'));

    }

    public function index()
    {
        $posts=Flight::where('paymentID','1')->get();
        // $posts=Flight::where('paymentID','1')->get();
        $flight=Flight::where('PaymentID','1')->take(1)->get();

      //$posts= DB::select('Select * from posts');
      return View::make('airways.confirmdetails')
                ->with(compact('posts'))
                ->with(compact('flight'));
    }

}
