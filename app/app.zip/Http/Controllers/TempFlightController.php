<?php

namespace App\Http\Controllers;

use App\TempFlight;
use Illuminate\Http\Request;

class TempFlightController extends Controller
{

}
